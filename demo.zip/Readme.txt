This is a simple tourism website
